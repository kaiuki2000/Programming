#include <stdio.h>

// Definição da função que permite calcular os termos da sucessão de Fibonacci (a função é definida por recorrência).
void
Fibbi(int *v, int n)
{
  int i;
  v[0]=0;
  v[1]=1;
  for(i=0;i<n;++i)
    v[i+2]=v[i+1]+v[i];
}
int main()
{
  // Declaração das variáveis. n é o número de elementos da sucessão que se vai calcular, v é o vetor que armazena os valores da sucessão e i é uma varíavel de contagem. P3 refere-se ao canal que permite a escrita dos valores obtidos num ficheiro de texto.
  int n, v[45],i,t1;
  FILE *P3;
  printf("Sucessão de Fibonacci\n\n");
  // Abertura do canal de escrita.
  P3=fopen("Prog3.txt","wt");
  printf("Quantos elementos pretende calcular? (menor que 45)\n");
  // Leitura de n.
 t1= scanf("%d",&n);
 // Testes para o valor lido.
 if (t1 !=1)
   {
     printf("A leitura não é válida.\n");
       return (0);
   }
 if (n<=0 || n>=45)
   {
     printf("O número introduzido não é valido (0<n<45)\n");
     return(0);
   }
  printf("\n");
  // Aplicação da função definida anteriormente.
  Fibbi(v,n);
  // Impressão dos resultados, tanto no terminal, como no ficheiro de texto.
  for(i=0;i<n;++i)
    {
      printf("%d: %d\n",i,v[i]);
      fprintf(P3,"%d: %d\n",i,v[i]);
      // A cada 6 linhas de texto mudamos de linha.
      if(i % 6==5)
	{
	  printf("\n");
	  fprintf(P3,"\n");

	}
    }
     
  return(0);
}
